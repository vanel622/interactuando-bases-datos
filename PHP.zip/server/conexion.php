<?php

$servername = "localhost";
$username = "root";
$password = "root";

$mysqli = new mysqli($servername, $username, $password, "agenda");

?>
